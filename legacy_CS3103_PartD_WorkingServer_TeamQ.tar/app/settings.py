#/usr/bin/env python
APP_HOST = 'cs3103.cs.unb.ca'
APP_PORT = 8017
APP_DEBUG = True

DB_HOST = 'localhost'
DB_USER = 'akothari'
DB_PASSWD = '5YQGP3wE'
DB_DATABASE = 'akothari'

SECRET_KEY = 'd41d8cd98f00b204e9800998ecf8427e'

LDAP_HOST =  'ldap-student.cs.unb.ca'